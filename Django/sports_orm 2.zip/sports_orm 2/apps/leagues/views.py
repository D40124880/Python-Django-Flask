from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Q

from . import team_maker

def index(request):
	baseball_league = League.objects.filter(sport = "Baseball")
	women_league = League.objects.filter(name__contains = "Women")
	hockey_league = League.objects.filter(sport__contains = "Hockey")
	nonfootball_league = League.objects.exclude(sport="Football")
	conference = League.objects.filter(name__contains = "Conference")
	atlantic = League.objects.filter(name__contains="Atlantic")
	dallas_team = Team.objects.filter(location="Dallas")
	raptor_team = Team.objects.filter(team_name__contains ="Raptors")
	city_team = Team.objects.filter(location__contains="City")
	beginT = Team.objects.filter(team_name__startswith="T")
	teams = Team.objects.order_by("location")
	cooper = Player.objects.filter(last_name="Cooper")
	joshua = Player.objects.filter(first_name="Joshua")	
	coop = Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua")
	alex = Player.objects.filter(Q(first_name="Alexander") | Q(first_name="Wyatt"))

	context = {
		"baseball": baseball_league,
		"hockey": hockey_league,
		"women" : women_league,
		"nonfootball" : nonfootball_league,
		"conference" : conference,
		"atlantic" : atlantic,
		"dallas" : dallas_team,
		"raptor" : raptor_team,
		"city" : city_team,
		"beginsT" : beginT,
		"teams" : teams,
		"cooper" : cooper,
		"joshua" : joshua,
		"coop" : coop,
		"alex" : alex,


		"teams": Team.objects.all(),
		"players": Player.objects.all(),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")